# Vinted Pro Listing Bot

A comprehensive FastAPI backend for automating Vinted listing management. The system provides photo ingestion with AI-powered drafts, automated category mapping, CSV imports, bulk operations, and scheduled price drops.

## 🎯 Features

- **AI Photo Analysis**: Upload photos and get automated listing drafts (with fallback for offline mode)
- **Smart Mapping**: Automatic category, size, and condition normalization
- **CSV Import**: Bulk import listings from CSV files
- **Mock Vinted API**: Simulated publish, relist, and retire operations
- **Price Automation**: Scheduled 5% price drops (respects minimum price)
- **RESTful API**: Complete FastAPI implementation with Swagger docs

## 📋 Flow

```
Photos → AI Draft → Item Creation → Mapping → Mock Publication → Scheduler
```

## 🚀 Quick Start

### Replit (Recommended)

1. Click the **Run** button
2. Access the API docs at `/docs`
3. No OpenAI key needed (uses simulated AI drafts)

### Local Installation (Windows/Mac/Linux)

```bash
# Install dependencies
pip install -r requirements.txt

# Start the server
uvicorn backend.app:app --host 127.0.0.1 --port 8000
```

### Windows Quick Start

Double-click `start_bot.bat` to:
- Create virtual environment
- Install dependencies
- Start the server on port 8001

Access at: http://127.0.0.1:8001/docs

## 📁 Project Structure

```
/
├── backend/
│   ├── app.py                 # FastAPI application & middleware
│   ├── routes/
│   │   ├── ingest.py          # POST /ingest/photos
│   │   ├── listings.py        # Publish & query listings
│   │   ├── bulk.py            # Bulk relist/retire operations
│   │   └── import_csv.py      # CSV import endpoint
│   ├── services/
│   │   ├── ai.py              # AI drafting (OpenAI + fallback)
│   │   ├── mapping.py         # Category/size/condition mapping
│   │   ├── pricing.py         # Automated price drops
│   │   └── vinted_api.py      # Mock Vinted API calls
│   ├── models/
│   │   └── db.py              # JSON-based CRUD operations
│   ├── jobs/
│   │   └── scheduler.py       # APScheduler for price drops
│   └── utils/
│       └── log.py             # Structured logging
├── data/
│   ├── items.json             # Items storage (auto-created)
│   └── publish_logs.json      # Publication logs (auto-created)
├── tests/                     # Pytest test suite
├── .env.example               # Environment variables template
└── requirements.txt           # Python dependencies
```

## 🔌 API Endpoints

### 1. Ingest Photos

**POST** `/ingest/photos`

Analyzes photos and creates a draft listing.

```bash
curl -X POST http://localhost:8000/ingest/photos \
  -H "Content-Type: application/json" \
  -d '{
    "photo_urls": ["https://picsum.photos/seed/1/800/800"]
  }'
```

**Response:**
```json
{
  "item_id": 1,
  "draft": {
    "title": "Article mode simulé",
    "description": "Description automatique...",
    "brand": "Marque Inconnue",
    "condition": "TTB",
    "price_suggestion": {"target": 45.0, "min": 35.0}
  }
}
```

### 2. Publish Listing

**POST** `/listings/publish/{item_id}`

Validates, maps, and publishes a listing.

```bash
curl -X POST http://localhost:8000/listings/publish/1
```

**Success Response:**
```json
{
  "ok": true,
  "id": "mock-1697123456",
  "status": "published"
}
```

**Missing Fields Response (422):**
```json
{
  "ok": false,
  "missing": ["category_id", "size"],
  "mapped": {...}
}
```

### 3. List Items

**GET** `/listings`

Query listings with filters and pagination.

```bash
# Filter by status
curl "http://localhost:8000/listings?status=published"

# Search by text
curl "http://localhost:8000/listings?q=pull"

# Sort by price
curl "http://localhost:8000/listings?sort=price_desc&page=1&page_size=10"
```

### 4. Get Single Item

**GET** `/listings/{item_id}`

```bash
curl http://localhost:8000/listings/1
```

### 5. Bulk Relist

**POST** `/listings/bulk/relist`

```bash
curl -X POST http://localhost:8000/listings/bulk/relist \
  -H "Content-Type: application/json" \
  -d '{
    "listing_ids": ["mock-1697123456", "mock-1697123457"]
  }'
```

### 6. Bulk Retire

**POST** `/listings/bulk/retire`

```bash
curl -X POST http://localhost:8000/listings/bulk/retire \
  -H "Content-Type: application/json" \
  -d '{
    "listing_ids": ["mock-1697123456"]
  }'
```

### 7. CSV Import

**POST** `/import`

Import multiple listings from CSV.

**CSV Format:**
```csv
sku,title,brand,condition,size,category_code,price,price_min,image_urls
SKU-001,Pull Noir,Zara,TTB,M,pull_tricot_homme,45.00,35.00,https://example.com/1.jpg;https://example.com/2.jpg
SKU-002,Jean Slim,Levis,Bon,32,jean_homme,65.00,50.00,https://example.com/3.jpg
```

```bash
curl -X POST http://localhost:8000/import \
  -F "file=@listings.csv"
```

**Response:**
```json
{
  "imported": 2
}
```

## ⚙️ Configuration

### Environment Variables (.env)

Copy `.env.example` to `.env` and configure:

```bash
# Optional: Enable real AI (leave empty for simulated mode)
OPENAI_API_KEY=

# Cron expression for price drops (default: 3 AM daily)
PRICE_DROP_CRON=0 3 * * *

# CORS allowed origins
ALLOWED_ORIGINS=http://localhost:3000,http://127.0.0.1:3000
```

### AI Mode

- **Without OPENAI_API_KEY**: Uses simulated drafts (works offline)
- **With OPENAI_API_KEY**: Uses GPT-4o-mini for real photo analysis

**Security**: The API key is never logged or exposed.

### Price Drop Scheduler

Automatically reduces prices by 5% at the scheduled time:
- Respects `price_min` (never goes below)
- Only affects published items
- Logs each price change

## 🧪 Testing

Run the test suite:

```bash
# Run all tests
pytest

# Run specific test file
pytest tests/test_api.py -v

# Run with coverage
pytest --cov=backend tests/
```

**Test Coverage:**
- API endpoints (ingest, publish, listings, import, bulk)
- Database operations (CRUD, pagination, filters)
- Mapping functions (category, size, condition)
- Pricing logic (5% drop, minimum enforcement)

## 📊 Data Storage

Uses JSON files for simplicity:

- `data/items.json` - All listing items
- `data/publish_logs.json` - Publication history

Files are auto-created on first run.

## 🔒 Security

- **CORS**: Configured for localhost origins
- **Request Size Limit**: 5MB max body size
- **Secret Management**: Environment variables for API keys
- **Log Safety**: Secrets are never logged

## ⚠️ Limitations

- **Mock Vinted API**: No real Vinted integration (simulated responses)
- **No Authentication**: API is open (add auth for production)
- **JSON Storage**: Not suitable for high-scale production (use PostgreSQL/MongoDB for real deployments)
- **Scheduler**: Single instance only (use distributed scheduler for scaling)

## 📝 Development

### Adding New Categories

Edit `backend/services/mapping.py`:

```python
category_map = {
    "pull_tricot_homme": 123456,
    "your_new_category": 999999,
}
```

### Changing Price Drop Logic

Edit `backend/services/pricing.py`:

```python
new_price = math.floor(current_price * 0.90 * 100) / 100  # 10% drop instead of 5%
```

## 🐛 Troubleshooting

### Port Already in Use

Change the port in the command:
```bash
uvicorn backend.app:app --host 0.0.0.0 --port 8001
```

### Module Not Found

Ensure dependencies are installed:
```bash
pip install -r requirements.txt
```

### Scheduler Not Running

Check logs for scheduler startup:
```
[scheduler] Scheduled price drop job with cron: 0 3 * * *
[scheduler] started
```

## 📚 API Documentation

Interactive API docs available at:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests: `pytest`
5. Submit a pull request

## 📄 License

MIT License - feel free to use this project for your own purposes.

## 🎯 Roadmap

- [ ] Real Vinted API integration
- [ ] User authentication & multi-tenancy
- [ ] PostgreSQL/MongoDB support
- [ ] Image optimization & CDN
- [ ] Advanced pricing strategies
- [ ] Email notifications
- [ ] Frontend dashboard

---

**Built with FastAPI + Python 3.11+ | Ready for Replit & Windows**
