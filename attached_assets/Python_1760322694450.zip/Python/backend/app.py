import os
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
from backend.routes import ingest, listings, bulk, import_csv
from backend.jobs.scheduler import start_scheduler
from backend.utils.log import get_logger

load_dotenv()

logger = get_logger(__name__)

app = FastAPI(
    title="Vinted Pro Listing Bot",
    version="1.0.0",
    description="Automated Vinted listing management with AI, CSV import, and price automation"
)

allowed_origins = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000").split(",")
allowed_origins.extend(["http://localhost:8000", "http://127.0.0.1:8000", "http://localhost:5000", "http://127.0.0.1:5000"])

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

MAX_BODY_SIZE = 5 * 1024 * 1024

@app.middleware("http")
async def limit_upload_size(request: Request, call_next):
    if request.method in ["POST", "PUT", "PATCH"]:
        content_length = request.headers.get("content-length")
        if content_length and int(content_length) > MAX_BODY_SIZE:
            return JSONResponse(
                status_code=413,
                content={"detail": "Request body too large (max 5MB)"}
            )
    return await call_next(request)

app.include_router(ingest.router)
app.include_router(listings.router)
app.include_router(bulk.router)
app.include_router(import_csv.router)

@app.get("/", tags=["health"])
async def root():
    return {
        "service": "Vinted Pro Listing Bot",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs"
    }

@app.on_event("startup")
async def startup_event():
    try:
        start_scheduler()
        logger.info("[app] Application started successfully")
    except Exception as e:
        logger.error(f"[app] Failed to start scheduler: {e}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
