import os
from apscheduler.schedulers.background import BackgroundScheduler
from backend.services.pricing import auto_price_drop
from backend.utils.log import get_logger

logger = get_logger(__name__)

scheduler = None

def start_scheduler():
    global scheduler
    
    if scheduler is not None:
        logger.info("[scheduler] Already started, skipping")
        return
    
    scheduler = BackgroundScheduler()
    
    cron_expr = os.getenv("PRICE_DROP_CRON", "0 3 * * *")
    parts = cron_expr.split()
    
    if len(parts) == 5:
        minute, hour, day, month, day_of_week = parts
        scheduler.add_job(
            auto_price_drop,
            'cron',
            minute=minute,
            hour=hour,
            day=day,
            month=month,
            day_of_week=day_of_week
        )
        logger.info(f"[scheduler] Scheduled price drop job with cron: {cron_expr}")
    else:
        scheduler.add_job(auto_price_drop, 'cron', hour=3, minute=0)
        logger.info("[scheduler] Scheduled price drop job at 03:00 daily (default)")
    
    scheduler.start()
    logger.info("[scheduler] started")
