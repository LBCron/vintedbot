import json
import os
from typing import Optional, Dict, List, Any
from pathlib import Path
import time

DATA_DIR = Path("data")
ITEMS_FILE = DATA_DIR / "items.json"
LOGS_FILE = DATA_DIR / "publish_logs.json"

def _ensure_data_files():
    DATA_DIR.mkdir(exist_ok=True)
    if not ITEMS_FILE.exists():
        ITEMS_FILE.write_text("[]")
    if not LOGS_FILE.exists():
        LOGS_FILE.write_text("[]")

def _load_items() -> List[Dict]:
    _ensure_data_files()
    return json.loads(ITEMS_FILE.read_text())

def _save_items(items: List[Dict]):
    _ensure_data_files()
    ITEMS_FILE.write_text(json.dumps(items, indent=2, ensure_ascii=False))

def db_all_items(
    filters: Optional[Dict] = None, 
    sort: Optional[str] = None, 
    page: int = 1, 
    page_size: int = 25
) -> Dict[str, Any]:
    items = _load_items()
    
    if filters:
        if filters.get("status"):
            items = [i for i in items if i.get("status") == filters["status"]]
        if filters.get("q"):
            q = filters["q"].lower()
            items = [i for i in items if q in i.get("title", "").lower() or q in i.get("brand", "").lower()]
    
    if sort == "price_asc":
        items = sorted(items, key=lambda x: x.get("price", 0))
    elif sort == "price_desc":
        items = sorted(items, key=lambda x: x.get("price", 0), reverse=True)
    elif sort == "date_desc":
        items = sorted(items, key=lambda x: x.get("id", 0), reverse=True)
    
    total = len(items)
    start = (page - 1) * page_size
    end = start + page_size
    paginated = items[start:end]
    
    return {
        "items": paginated,
        "page": page,
        "page_size": page_size,
        "total": total
    }

def db_create_item(draft: Dict, photo_urls: List[str]) -> int:
    items = _load_items()
    item_id = max([i["id"] for i in items], default=0) + 1
    sku = f"SKU-{int(time.time())}"
    
    item = {
        "id": item_id,
        "sku": sku,
        "title": draft.get("title", ""),
        "description": draft.get("description", ""),
        "brand": draft.get("brand", ""),
        "size": draft.get("size_guess", ""),
        "condition": draft.get("condition", "TTB"),
        "category_code": draft.get("category_guess", ""),
        "price": float(draft.get("price_suggestion", {}).get("target", 0)),
        "price_min": float(draft.get("price_suggestion", {}).get("min", 0)),
        "image_urls": photo_urls,
        "status": "draft",
        "vinted_listing_id": None
    }
    
    items.append(item)
    _save_items(items)
    return item_id

def db_upsert_item(row: Dict, image_urls: List[str]):
    items = _load_items()
    sku = row.get("sku")
    
    existing_idx = None
    for idx, item in enumerate(items):
        if item.get("sku") == sku:
            existing_idx = idx
            break
    
    item_data = {
        "sku": sku,
        "title": row.get("title", ""),
        "brand": row.get("brand", ""),
        "condition": row.get("condition", "TTB"),
        "size": row.get("size", ""),
        "category_code": row.get("category_code", ""),
        "price": float(row.get("price", 0)),
        "price_min": float(row.get("price_min", 0)),
        "image_urls": image_urls,
        "status": "draft",
        "vinted_listing_id": None
    }
    
    if existing_idx is not None:
        items[existing_idx].update(item_data)
    else:
        item_id = max([i["id"] for i in items], default=0) + 1
        item_data["id"] = item_id
        items.append(item_data)
    
    _save_items(items)

def db_get_item(item_id: int) -> Optional[Dict]:
    items = _load_items()
    for item in items:
        if item["id"] == item_id:
            return item
    return None

def db_update_price(item_id: int, price: float):
    items = _load_items()
    for item in items:
        if item["id"] == item_id:
            item["price"] = price
            break
    _save_items(items)

def db_set_published(item_id: int, listing_id: str):
    items = _load_items()
    for item in items:
        if item["id"] == item_id:
            item["status"] = "published"
            item["vinted_listing_id"] = listing_id
            break
    _save_items(items)

def db_log_publish(item_id: int, mapped: Dict, response: Dict):
    _ensure_data_files()
    logs = json.loads(LOGS_FILE.read_text())
    log_entry = {
        "timestamp": time.time(),
        "item_id": item_id,
        "mapped": mapped,
        "response": response
    }
    logs.append(log_entry)
    LOGS_FILE.write_text(json.dumps(logs, indent=2, ensure_ascii=False))
