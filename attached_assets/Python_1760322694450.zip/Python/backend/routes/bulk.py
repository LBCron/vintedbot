from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Dict
from backend.services.vinted_api import bulk_relist, bulk_retire

router = APIRouter(prefix="/listings/bulk", tags=["bulk"])

class BulkRequest(BaseModel):
    listing_ids: List[str]

class BulkResponse(BaseModel):
    relisted: List[str] = []
    retired: List[str] = []
    errors: List[str] = []

@router.post("/relist", response_model=BulkResponse)
async def relist_items(req: BulkRequest):
    result = await bulk_relist(req.listing_ids)
    return BulkResponse(relisted=result["relisted"], errors=result["errors"])

@router.post("/retire", response_model=BulkResponse)
async def retire_items(req: BulkRequest):
    result = await bulk_retire(req.listing_ids)
    return BulkResponse(retired=result["retired"], errors=result["errors"])
