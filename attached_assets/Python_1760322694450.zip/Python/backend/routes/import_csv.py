from fastapi import APIRouter, UploadFile, File, HTTPException
from pydantic import BaseModel
import csv
import io
from backend.models.db import db_upsert_item

router = APIRouter(prefix="/import", tags=["import"])

class ImportResponse(BaseModel):
    imported: int

@router.post("", response_model=ImportResponse)
async def import_csv(file: UploadFile = File(...)):
    if not file.filename or not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="File must be a CSV")
    
    try:
        content = await file.read()
        text_content = content.decode('utf-8')
        reader = csv.DictReader(io.StringIO(text_content))
        
        expected_headers = {'sku', 'title', 'brand', 'condition', 'size', 'category_code', 'price', 'price_min', 'image_urls'}
        if not expected_headers.issubset(set(reader.fieldnames or [])):
            raise HTTPException(status_code=400, detail=f"CSV must contain headers: {expected_headers}")
        
        count = 0
        for row in reader:
            image_urls = row.get('image_urls', '').split(';') if row.get('image_urls') else []
            image_urls = [url.strip() for url in image_urls if url.strip()]
            
            db_upsert_item(row, image_urls)
            count += 1
        
        return ImportResponse(imported=count)
    
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="Invalid CSV encoding, must be UTF-8")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"CSV processing error: {str(e)}")
