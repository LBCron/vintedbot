from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict
from backend.services.ai import draft_from_photos
from backend.models.db import db_create_item

router = APIRouter(prefix="/ingest", tags=["ingest"])

class IngestRequest(BaseModel):
    photo_urls: List[str]

class IngestResponse(BaseModel):
    item_id: int
    draft: Dict

@router.post("/photos", response_model=IngestResponse)
async def ingest_photos(req: IngestRequest):
    if not req.photo_urls or len(req.photo_urls) == 0:
        raise HTTPException(status_code=400, detail="photo_urls cannot be empty")
    
    draft = draft_from_photos(req.photo_urls)
    
    item_id = db_create_item(draft, req.photo_urls)
    
    return IngestResponse(item_id=item_id, draft=draft)
