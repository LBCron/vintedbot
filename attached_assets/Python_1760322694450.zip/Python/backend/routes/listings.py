from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import Optional, Dict, List, Any
from backend.models.db import db_get_item, db_all_items, db_log_publish, db_set_published
from backend.services.mapping import map_category, map_size, map_condition, validate_required
from backend.services.vinted_api import publish_listing

router = APIRouter(prefix="/listings", tags=["listings"])

class PublishResponse(BaseModel):
    ok: bool
    id: Optional[str] = None
    status: Optional[str] = None
    error: Optional[str] = None
    missing: Optional[List[str]] = None
    mapped: Optional[Dict] = None

class ListingsResponse(BaseModel):
    items: List[Dict]
    page: int
    page_size: int
    total: int

@router.post("/publish/{item_id}", response_model=PublishResponse)
async def publish_item(item_id: int):
    item = db_get_item(item_id)
    
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    
    category_id = map_category(item.get("category_code", ""))
    size = map_size(item.get("size", ""), item.get("category_code", ""))
    condition = map_condition(item.get("condition", "TTB"))
    
    mapped = {
        "title": item.get("title"),
        "description": item.get("description"),
        "price": item.get("price"),
        "category_id": category_id,
        "size": size,
        "condition": condition,
        "photos": item.get("image_urls", [])
    }
    
    missing = validate_required(mapped)
    
    if missing:
        raise HTTPException(
            status_code=422,
            detail={
                "message": "Missing required fields",
                "missing": missing,
                "mapped": mapped
            }
        )
    
    response = await publish_listing(mapped)
    
    db_log_publish(item_id, mapped, response)
    
    if response.get("ok"):
        db_set_published(item_id, response["id"])
        return PublishResponse(ok=True, id=response["id"], status="published")
    else:
        return PublishResponse(ok=False, error=response.get("error"))

@router.get("/", response_model=ListingsResponse)
async def get_listings(
    status: Optional[str] = Query(None),
    q: Optional[str] = Query(None),
    sort: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100)
):
    filters = {}
    if status:
        filters["status"] = status
    if q:
        filters["q"] = q
    
    result = db_all_items(filters=filters, sort=sort, page=page, page_size=page_size)
    return ListingsResponse(**result)

@router.get("/{item_id}")
async def get_item(item_id: int):
    item = db_get_item(item_id)
    
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    
    return item
