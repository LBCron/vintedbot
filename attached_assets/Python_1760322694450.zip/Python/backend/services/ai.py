import os
from typing import Dict, List
from backend.utils.log import get_logger

logger = get_logger(__name__)

def draft_from_photos(photo_urls: List[str]) -> Dict:
    openai_key = os.getenv("OPENAI_API_KEY")
    
    if not openai_key:
        logger.info("[AI] No OPENAI_API_KEY found, using simulated draft")
        return _simulated_draft(photo_urls)
    
    try:
        from openai import OpenAI
        client = OpenAI(api_key=openai_key)
        
        prompt = f"""Analyze these photos and return ONLY a JSON object (no markdown, no extra text) with this exact structure:
{{
  "title": "concise item name",
  "description": "detailed description",
  "brand": "brand name or Unknown",
  "condition": "TTB|Bon|Correct|Neuf",
  "size_guess": "size estimation",
  "category_guess": "category code",
  "keywords": ["keyword1", "keyword2"],
  "price_suggestion": {{"target": 45.0, "min": 35.0, "rationale": "why"}},
  "missing_info": ["what info is unclear"],
  "detected_defects": [],
  "photos": {photo_urls}
}}

Photos: {photo_urls}"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a Vinted listing expert. Return ONLY valid JSON, no markdown."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )
        
        import json
        content = response.choices[0].message.content or ""
        content = content.strip()
        if content.startswith("```"):
            content = content.split("```")[1]
            if content.startswith("json"):
                content = content[4:]
            content = content.strip()
        
        draft = json.loads(content)
        logger.info(f"[AI] Generated draft from OpenAI: {draft.get('title')}")
        return draft
        
    except Exception as e:
        logger.warning(f"[AI] OpenAI failed ({str(e)}), falling back to simulated draft")
        return _simulated_draft(photo_urls)

def _simulated_draft(photo_urls: List[str]) -> Dict:
    return {
        "title": "Article mode simulé",
        "description": "Description automatique générée à partir des photos. Détails à compléter manuellement.",
        "brand": "Marque Inconnue",
        "condition": "TTB",
        "size_guess": "M",
        "category_guess": "pull_tricot_homme",
        "keywords": ["mode", "vêtement", "occasion"],
        "price_suggestion": {
            "target": 45.0,
            "min": 35.0,
            "rationale": "Prix estimé basé sur catégorie similaire"
        },
        "missing_info": ["brand", "exact_size"],
        "detected_defects": [],
        "photos": photo_urls
    }
