from typing import Dict, List, Optional

category_map = {
    "pull_tricot_homme": 123456,
    "jean_homme": 456789,
    "chemise_homme": 789012,
    "pantalon_homme": 345678,
    "veste_homme": 901234,
    "pull_tricot_femme": 123457,
    "jean_femme": 456790,
    "robe_femme": 789013,
    "jupe_femme": 345679,
    "chaussures_homme": 567890,
    "chaussures_femme": 567891,
    "sneakers": 567892,
    "boots": 567893,
}

size_map = {
    "homme": ["XS", "S", "M", "L", "XL", "XXL", "XXXL"],
    "femme": ["XS", "S", "M", "L", "XL", "XXL"],
    "chaussures": ["36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46"]
}

condition_map = {
    "TTB": "very_good",
    "Bon": "good",
    "Correct": "satisfactory",
    "Neuf": "new_with_tags"
}

def map_category(code: str) -> Optional[int]:
    return category_map.get(code)

def map_size(size: str, category_code: str) -> str:
    if "chaussures" in category_code.lower() or "sneakers" in category_code.lower() or "boots" in category_code.lower():
        if size in size_map["chaussures"]:
            return size
        return size
    
    if "femme" in category_code.lower():
        if size.upper() in size_map["femme"]:
            return size.upper()
    
    if "homme" in category_code.lower():
        if size.upper() in size_map["homme"]:
            return size.upper()
    
    return size.upper() if size else "M"

def map_condition(label: str) -> str:
    return condition_map.get(label, "good")

def validate_required(mapped: Dict) -> List[str]:
    required_fields = ["title", "description", "price", "category_id", "size", "condition", "photos"]
    missing = []
    
    for field in required_fields:
        if field not in mapped or not mapped[field]:
            missing.append(field)
    
    if "photos" in mapped and isinstance(mapped["photos"], list):
        if len(mapped["photos"]) == 0:
            if "photos" not in missing:
                missing.append("photos")
    
    return missing
