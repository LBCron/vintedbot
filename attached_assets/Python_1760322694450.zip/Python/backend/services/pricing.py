from backend.models.db import _load_items, db_update_price
from backend.utils.log import get_logger
import math

logger = get_logger(__name__)

def auto_price_drop():
    items = _load_items()
    dropped_count = 0
    
    for item in items:
        if item.get("status") != "published":
            continue
        
        current_price = float(item.get("price", 0))
        price_min = float(item.get("price_min", 0))
        
        if current_price <= price_min:
            continue
        
        new_price = math.floor(current_price * 0.95 * 100) / 100
        
        if new_price >= price_min and new_price < current_price:
            db_update_price(item["id"], new_price)
            logger.info(f"[price_drop] id={item['id']} old={current_price} new={new_price}")
            dropped_count += 1
    
    logger.info(f"[price_drop] Completed: {dropped_count} prices dropped")
    return {"dropped": dropped_count}
