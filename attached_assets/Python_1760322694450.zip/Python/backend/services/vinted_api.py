import time
import asyncio
from typing import Dict, List
from backend.utils.log import get_logger

logger = get_logger(__name__)

async def publish_listing(mapped: Dict) -> Dict:
    await asyncio.sleep(0.5)
    
    if not mapped.get("title") or not mapped.get("price"):
        logger.error(f"[vinted_api] Invalid data for publish: {mapped}")
        return {"ok": False, "error": "Invalid listing data"}
    
    listing_id = f"mock-{int(time.time())}"
    logger.info(f"[vinted_api] Published listing: {listing_id}")
    
    return {"ok": True, "id": listing_id}

async def bulk_relist(listing_ids: List[str]) -> Dict:
    await asyncio.sleep(0.3)
    
    if not listing_ids:
        return {"relisted": [], "errors": ["No IDs provided"]}
    
    relisted = []
    errors = []
    
    for lid in listing_ids:
        if lid.startswith("mock-"):
            relisted.append(lid)
            logger.info(f"[vinted_api] Relisted: {lid}")
        else:
            errors.append(f"Invalid ID: {lid}")
    
    return {"relisted": relisted, "errors": errors}

async def bulk_retire(listing_ids: List[str]) -> Dict:
    await asyncio.sleep(0.3)
    
    if not listing_ids:
        return {"retired": [], "errors": ["No IDs provided"]}
    
    retired = []
    errors = []
    
    for lid in listing_ids:
        if lid.startswith("mock-"):
            retired.append(lid)
            logger.info(f"[vinted_api] Retired: {lid}")
        else:
            errors.append(f"Invalid ID: {lid}")
    
    return {"retired": retired, "errors": errors}
