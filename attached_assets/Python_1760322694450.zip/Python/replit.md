# Vinted Pro Listing Bot

## Overview

The Vinted Pro Listing Bot is a FastAPI-based automation system for managing Vinted listings. It provides intelligent photo ingestion with AI-powered drafting, automated category/size/condition mapping, CSV bulk imports, and scheduled price automation. The system is designed to work both with and without internet connectivity, featuring a fallback mode when OpenAI API is unavailable.

**Core Purpose**: Streamline the creation and management of Vinted listings through automation, reducing manual effort in categorization, pricing, and lifecycle management.

**Key Capabilities**:
- Photo-to-listing conversion with AI analysis
- Bulk operations via CSV import
- Automated price drops on schedule
- Mock Vinted API for testing and development
- RESTful API with comprehensive documentation

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Application Framework
- **Framework**: FastAPI with Uvicorn ASGI server
- **Language**: Python 3.11+
- **Design Pattern**: Service-oriented architecture with clear separation of concerns
- **Rationale**: FastAPI provides automatic API documentation, type validation via Pydantic, and async support for efficient I/O operations

### Data Storage
- **Solution**: JSON file-based storage (no database)
- **Files**: 
  - `data/items.json` - All listing items
  - `data/publish_logs.json` - Publication history
- **Rationale**: Simple, portable, no database setup required. Suitable for small-to-medium datasets and easy deployment
- **Trade-offs**: Not suitable for high-concurrency scenarios; limited query capabilities compared to SQL databases

### AI Integration
- **Provider**: OpenAI GPT-4o-mini
- **Fallback Mode**: Simulated AI drafts when API key unavailable
- **Purpose**: Generate listing details (title, description, pricing suggestions) from photo URLs
- **Design Decision**: Environment-based toggle allows offline development and testing without API costs

### Data Mapping & Normalization
- **Category Mapping**: Hardcoded dictionary mapping category codes to Vinted category IDs
- **Size Normalization**: Context-aware mapping (homme/femme/chaussures) with defaults
- **Condition Mapping**: Translates French conditions (TTB, Bon, Correct, Neuf) to Vinted API values
- **Validation**: Pre-publish checks for required fields (title, price, category, size, photos)
- **Rationale**: Ensures data consistency before API submission; prevents publishing errors

### Price Automation
- **Strategy**: Scheduled 5% price drops on published listings
- **Scheduler**: APScheduler with configurable cron expressions (default: 03:00 daily)
- **Safety**: Respects minimum price thresholds; only affects published items
- **Calculation**: Floor-based rounding to avoid fractional cent issues

### API Integration
- **Vinted API**: Mock implementation for development/testing
- **Operations**: Publish, bulk relist, bulk retire
- **Logging**: All API operations logged with timestamps and payloads
- **Design Decision**: Mock API allows full system testing without Vinted API credentials

### Request Handling & Middleware
- **CORS**: Configurable allowed origins via environment variables
- **Rate Limiting**: 5MB max request body size to prevent abuse
- **Error Handling**: HTTP-specific error responses with detailed messages
- **Validation**: Pydantic models for request/response type safety

### Module Organization
```
backend/
├── routes/        # API endpoints (ingest, listings, bulk, import)
├── services/      # Business logic (AI, mapping, pricing, vinted_api)
├── models/        # Data access layer (db.py)
├── jobs/          # Background tasks (scheduler)
└── utils/         # Shared utilities (logging)
```

**Separation Rationale**: 
- Routes handle HTTP concerns only
- Services contain reusable business logic
- Models isolate data persistence
- Jobs manage asynchronous/scheduled tasks

### Testing Strategy
- **Framework**: pytest
- **Approach**: Unit tests for core services (mapping, pricing, DB operations) and integration tests for API endpoints
- **Isolation**: Temporary directories for test data; environment variable mocking
- **Coverage**: Critical paths including AI fallback, validation, and price logic

### Deployment Considerations
- **Cross-Platform**: Windows batch scripts + Unix compatibility
- **Environment Config**: `.env` file for configuration (API keys, CORS, cron)
- **Portability**: No OS-specific dependencies; runs on Replit (0.0.0.0:8000) and local (127.0.0.1:8000/8001)

## External Dependencies

### Required Python Packages
- **fastapi**: Web framework for API development
- **uvicorn**: ASGI server for running FastAPI
- **pydantic**: Data validation and settings management
- **python-dotenv**: Environment variable loading from .env files
- **apscheduler**: Background job scheduling for price automation
- **python-multipart**: File upload handling for CSV imports
- **pytest**: Testing framework

### Optional Dependencies
- **openai**: OpenAI API client for GPT-4o-mini integration (optional - system has fallback)
- **httpx**: Async HTTP client (used by tests)

### External Services
- **OpenAI API** (optional):
  - Model: gpt-4o-mini
  - Purpose: Photo-to-listing draft generation
  - Fallback: Simulated drafts when API key not configured
  - Configuration: `OPENAI_API_KEY` environment variable

### Environment Variables
- `OPENAI_API_KEY`: OpenAI API key (optional)
- `ALLOWED_ORIGINS`: CORS allowed origins (comma-separated)
- `PRICE_DROP_CRON`: Cron expression for price drop schedule (default: `0 3 * * *`)

### Data Sources
- **Photo URLs**: External image URLs provided by user (no local storage)
- **CSV Imports**: UTF-8 encoded CSV files with predefined schema (sku, title, brand, condition, size, category_code, price, price_min, image_urls)

### Infrastructure Requirements
- Python 3.11+ runtime
- File system access for JSON data storage
- Network access for OpenAI API (when enabled) and photo URL retrieval