import pytest
from fastapi.testclient import TestClient
from backend.app import app
import json
import os
from pathlib import Path

client = TestClient(app)

@pytest.fixture(autouse=True)
def setup_test_env(tmp_path, monkeypatch):
    test_data_dir = tmp_path / "data"
    test_data_dir.mkdir()
    monkeypatch.setattr("backend.models.db.DATA_DIR", test_data_dir)
    monkeypatch.setattr("backend.models.db.ITEMS_FILE", test_data_dir / "items.json")
    monkeypatch.setattr("backend.models.db.LOGS_FILE", test_data_dir / "publish_logs.json")
    
    (test_data_dir / "items.json").write_text("[]")
    (test_data_dir / "publish_logs.json").write_text("[]")
    
    if "OPENAI_API_KEY" in os.environ:
        monkeypatch.delenv("OPENAI_API_KEY")

def test_root():
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["service"] == "Vinted Pro Listing Bot"
    assert data["status"] == "running"

def test_ingest_photos():
    response = client.post("/ingest/photos", json={
        "photo_urls": ["https://picsum.photos/seed/test/800/800"]
    })
    assert response.status_code == 200
    data = response.json()
    assert "item_id" in data
    assert "draft" in data
    assert data["item_id"] == 1
    assert data["draft"]["title"] is not None

def test_ingest_photos_empty():
    response = client.post("/ingest/photos", json={
        "photo_urls": []
    })
    assert response.status_code == 400

def test_publish_listing_404():
    response = client.post("/listings/publish/999")
    assert response.status_code == 404

def test_publish_listing_missing_fields():
    from backend.models import db
    
    draft = {
        "title": "",
        "description": "",
        "price_suggestion": {"target": 0, "min": 0}
    }
    item_id = db.db_create_item(draft, [])
    
    publish_response = client.post(f"/listings/publish/{item_id}")
    assert publish_response.status_code == 422
    data = publish_response.json()
    assert "detail" in data
    assert "missing" in data["detail"]

def test_publish_listing_success():
    ingest_response = client.post("/ingest/photos", json={
        "photo_urls": ["https://picsum.photos/seed/test2/800/800"]
    })
    item_id = ingest_response.json()["item_id"]
    
    publish_response = client.post(f"/listings/publish/{item_id}")
    assert publish_response.status_code == 200
    data = publish_response.json()
    assert data["ok"] == True
    assert data["status"] == "published"
    assert "id" in data
    assert data["id"].startswith("mock-")

def test_get_listings():
    client.post("/ingest/photos", json={
        "photo_urls": ["https://picsum.photos/seed/list1/800/800"]
    })
    client.post("/ingest/photos", json={
        "photo_urls": ["https://picsum.photos/seed/list2/800/800"]
    })
    
    response = client.get("/listings")
    assert response.status_code == 200
    data = response.json()
    assert "items" in data
    assert len(data["items"]) == 2
    assert data["total"] == 2
    assert data["page"] == 1

def test_get_listings_filter():
    client.post("/ingest/photos", json={
        "photo_urls": ["https://picsum.photos/seed/filter/800/800"]
    })
    
    response = client.get("/listings?status=draft")
    assert response.status_code == 200
    data = response.json()
    assert len(data["items"]) >= 1

def test_get_item():
    ingest_response = client.post("/ingest/photos", json={
        "photo_urls": ["https://picsum.photos/seed/getitem/800/800"]
    })
    item_id = ingest_response.json()["item_id"]
    
    response = client.get(f"/listings/{item_id}")
    assert response.status_code == 200
    data = response.json()
    assert data["id"] == item_id

def test_import_csv(tmp_path):
    csv_content = """sku,title,brand,condition,size,category_code,price,price_min,image_urls
SKU-TEST1,Pull Test,TestBrand,TTB,M,pull_tricot_homme,45.00,35.00,https://example.com/1.jpg
SKU-TEST2,Jean Test,TestBrand2,Bon,L,jean_homme,65.00,50.00,https://example.com/2.jpg;https://example.com/3.jpg"""
    
    csv_file = tmp_path / "test.csv"
    csv_file.write_text(csv_content)
    
    with open(csv_file, "rb") as f:
        response = client.post("/import", files={"file": ("test.csv", f, "text/csv")})
    
    assert response.status_code == 200
    data = response.json()
    assert data["imported"] == 2

def test_bulk_relist():
    response = client.post("/listings/bulk/relist", json={
        "listing_ids": ["mock-123", "mock-456"]
    })
    assert response.status_code == 200
    data = response.json()
    assert len(data["relisted"]) == 2

def test_bulk_retire():
    response = client.post("/listings/bulk/retire", json={
        "listing_ids": ["mock-789"]
    })
    assert response.status_code == 200
    data = response.json()
    assert len(data["retired"]) == 1
