import pytest
from pathlib import Path
import json
from backend.models import db

@pytest.fixture
def test_data_dir(tmp_path, monkeypatch):
    test_dir = tmp_path / "data"
    test_dir.mkdir()
    monkeypatch.setattr("backend.models.db.DATA_DIR", test_dir)
    monkeypatch.setattr("backend.models.db.ITEMS_FILE", test_dir / "items.json")
    monkeypatch.setattr("backend.models.db.LOGS_FILE", test_dir / "publish_logs.json")
    return test_dir

def test_ensure_data_files(test_data_dir):
    db._ensure_data_files()
    assert (test_data_dir / "items.json").exists()
    assert (test_data_dir / "publish_logs.json").exists()

def test_create_item(test_data_dir):
    draft = {
        "title": "Test Item",
        "description": "Test Description",
        "brand": "TestBrand",
        "condition": "TTB",
        "size_guess": "M",
        "category_guess": "pull_tricot_homme",
        "price_suggestion": {"target": 45.0, "min": 35.0}
    }
    photo_urls = ["https://example.com/photo1.jpg"]
    
    item_id = db.db_create_item(draft, photo_urls)
    assert item_id == 1
    
    item = db.db_get_item(item_id)
    assert item is not None
    assert item["title"] == "Test Item"
    assert item["brand"] == "TestBrand"
    assert item["price"] == 45.0
    assert item["price_min"] == 35.0
    assert item["status"] == "draft"

def test_upsert_item_create(test_data_dir):
    row = {
        "sku": "SKU-NEW",
        "title": "New Item",
        "brand": "Brand1",
        "condition": "Bon",
        "size": "L",
        "category_code": "jean_homme",
        "price": "55.00",
        "price_min": "40.00"
    }
    
    db.db_upsert_item(row, ["https://example.com/img.jpg"])
    
    items = db._load_items()
    assert len(items) == 1
    assert items[0]["sku"] == "SKU-NEW"
    assert items[0]["title"] == "New Item"

def test_upsert_item_update(test_data_dir):
    row1 = {
        "sku": "SKU-UPDATE",
        "title": "Original",
        "brand": "Brand1",
        "condition": "TTB",
        "size": "M",
        "category_code": "pull_tricot_homme",
        "price": "45.00",
        "price_min": "35.00"
    }
    db.db_upsert_item(row1, ["https://example.com/1.jpg"])
    
    row2 = {
        "sku": "SKU-UPDATE",
        "title": "Updated",
        "brand": "Brand2",
        "condition": "Bon",
        "size": "L",
        "category_code": "jean_homme",
        "price": "65.00",
        "price_min": "50.00"
    }
    db.db_upsert_item(row2, ["https://example.com/2.jpg"])
    
    items = db._load_items()
    assert len(items) == 1
    assert items[0]["title"] == "Updated"
    assert items[0]["brand"] == "Brand2"

def test_update_price(test_data_dir):
    draft = {
        "title": "Price Test",
        "price_suggestion": {"target": 100.0, "min": 80.0}
    }
    item_id = db.db_create_item(draft, [])
    
    db.db_update_price(item_id, 95.0)
    
    item = db.db_get_item(item_id)
    assert item is not None
    assert item["price"] == 95.0

def test_set_published(test_data_dir):
    draft = {
        "title": "Publish Test",
        "price_suggestion": {"target": 50.0, "min": 40.0}
    }
    item_id = db.db_create_item(draft, [])
    
    db.db_set_published(item_id, "mock-12345")
    
    item = db.db_get_item(item_id)
    assert item is not None
    assert item["status"] == "published"
    assert item["vinted_listing_id"] == "mock-12345"

def test_all_items_pagination(test_data_dir):
    for i in range(30):
        draft = {
            "title": f"Item {i}",
            "price_suggestion": {"target": 10.0 + i, "min": 5.0}
        }
        db.db_create_item(draft, [])
    
    result = db.db_all_items(page=1, page_size=10)
    assert len(result["items"]) == 10
    assert result["total"] == 30
    assert result["page"] == 1
    
    result2 = db.db_all_items(page=2, page_size=10)
    assert len(result2["items"]) == 10

def test_all_items_filter(test_data_dir):
    draft1 = {"title": "Draft Item", "price_suggestion": {"target": 10.0, "min": 5.0}}
    draft2 = {"title": "Published Item", "price_suggestion": {"target": 20.0, "min": 10.0}}
    
    id1 = db.db_create_item(draft1, [])
    id2 = db.db_create_item(draft2, [])
    db.db_set_published(id2, "mock-123")
    
    result = db.db_all_items(filters={"status": "published"})
    assert len(result["items"]) == 1
    assert result["items"][0]["id"] == id2

def test_log_publish(test_data_dir):
    mapped = {"title": "Test", "price": 45}
    response = {"ok": True, "id": "mock-123"}
    
    db.db_log_publish(1, mapped, response)
    
    logs = json.loads((test_data_dir / "publish_logs.json").read_text())
    assert len(logs) == 1
    assert logs[0]["item_id"] == 1
    assert logs[0]["response"]["ok"] == True
