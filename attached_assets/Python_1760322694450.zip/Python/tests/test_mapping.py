import pytest
from backend.services.mapping import map_category, map_size, map_condition, validate_required

def test_map_category():
    assert map_category("pull_tricot_homme") == 123456
    assert map_category("jean_homme") == 456789
    assert map_category("unknown_category") is None

def test_map_size_homme():
    assert map_size("M", "pull_tricot_homme") == "M"
    assert map_size("l", "jean_homme") == "L"
    assert map_size("xs", "chemise_homme") == "XS"

def test_map_size_femme():
    assert map_size("S", "pull_tricot_femme") == "S"
    assert map_size("m", "robe_femme") == "M"

def test_map_size_chaussures():
    assert map_size("42", "chaussures_homme") == "42"
    assert map_size("38", "chaussures_femme") == "38"
    assert map_size("41", "sneakers") == "41"

def test_map_size_default():
    assert map_size("", "pull_tricot_homme") == "M"
    assert map_size("", "jean_homme") == "M"

def test_map_condition():
    assert map_condition("TTB") == "very_good"
    assert map_condition("Bon") == "good"
    assert map_condition("Correct") == "satisfactory"
    assert map_condition("Neuf") == "new_with_tags"
    assert map_condition("Unknown") == "good"

def test_validate_required_complete():
    mapped = {
        "title": "Test",
        "description": "Desc",
        "price": 45.0,
        "category_id": 123456,
        "size": "M",
        "condition": "very_good",
        "photos": ["https://example.com/1.jpg"]
    }
    
    missing = validate_required(mapped)
    assert len(missing) == 0

def test_validate_required_missing_title():
    mapped = {
        "description": "Desc",
        "price": 45.0,
        "category_id": 123456,
        "size": "M",
        "condition": "very_good",
        "photos": ["https://example.com/1.jpg"]
    }
    
    missing = validate_required(mapped)
    assert "title" in missing

def test_validate_required_missing_photos():
    mapped = {
        "title": "Test",
        "description": "Desc",
        "price": 45.0,
        "category_id": 123456,
        "size": "M",
        "condition": "very_good",
        "photos": []
    }
    
    missing = validate_required(mapped)
    assert "photos" in missing

def test_validate_required_missing_multiple():
    mapped = {
        "title": "Test",
        "photos": ["https://example.com/1.jpg"]
    }
    
    missing = validate_required(mapped)
    assert "description" in missing
    assert "price" in missing
    assert "category_id" in missing
    assert "size" in missing
    assert "condition" in missing
