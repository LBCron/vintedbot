import pytest
from backend.services.pricing import auto_price_drop
from backend.models import db

@pytest.fixture
def test_data_dir(tmp_path, monkeypatch):
    test_dir = tmp_path / "data"
    test_dir.mkdir()
    monkeypatch.setattr("backend.models.db.DATA_DIR", test_dir)
    monkeypatch.setattr("backend.models.db.ITEMS_FILE", test_dir / "items.json")
    monkeypatch.setattr("backend.models.db.LOGS_FILE", test_dir / "publish_logs.json")
    (test_dir / "items.json").write_text("[]")
    (test_dir / "publish_logs.json").write_text("[]")
    return test_dir

def test_price_drop_5_percent(test_data_dir):
    draft = {
        "title": "Test Item",
        "price_suggestion": {"target": 100.0, "min": 80.0}
    }
    item_id = db.db_create_item(draft, [])
    db.db_set_published(item_id, "mock-123")
    
    result = auto_price_drop()
    
    item = db.db_get_item(item_id)
    assert item is not None
    assert item["price"] == 95.0
    assert result["dropped"] == 1

def test_price_drop_respects_minimum(test_data_dir):
    draft = {
        "title": "Test Item",
        "price_suggestion": {"target": 85.0, "min": 80.0}
    }
    item_id = db.db_create_item(draft, [])
    db.db_set_published(item_id, "mock-456")
    
    result = auto_price_drop()
    
    item = db.db_get_item(item_id)
    assert item is not None
    assert item["price"] == 80.75
    
    result2 = auto_price_drop()
    item2 = db.db_get_item(item_id)
    assert item2 is not None
    assert item2["price"] == 80.75

def test_price_drop_skips_draft(test_data_dir):
    draft = {
        "title": "Draft Item",
        "price_suggestion": {"target": 100.0, "min": 80.0}
    }
    item_id = db.db_create_item(draft, [])
    
    result = auto_price_drop()
    
    item = db.db_get_item(item_id)
    assert item is not None
    assert item["price"] == 100.0
    assert result["dropped"] == 0

def test_price_drop_multiple_items(test_data_dir):
    for i in range(3):
        draft = {
            "title": f"Item {i}",
            "price_suggestion": {"target": 100.0, "min": 50.0}
        }
        item_id = db.db_create_item(draft, [])
        db.db_set_published(item_id, f"mock-{i}")
    
    result = auto_price_drop()
    assert result["dropped"] == 3
    
    items = db._load_items()
    for item in items:
        assert item["price"] == 95.0

def test_price_drop_at_minimum(test_data_dir):
    draft = {
        "title": "Minimum Price",
        "price_suggestion": {"target": 50.0, "min": 50.0}
    }
    item_id = db.db_create_item(draft, [])
    db.db_set_published(item_id, "mock-min")
    
    result = auto_price_drop()
    
    item = db.db_get_item(item_id)
    assert item is not None
    assert item["price"] == 50.0
    assert result["dropped"] == 0
